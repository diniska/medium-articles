import UIKit

public extension UIImage {
    public static func with(color: UIColor, size: CGSize) -> UIImage {
        UIGraphicsBeginImageContext(size)
        defer { UIGraphicsEndImageContext() }
        
        color.setFill()
        UIRectFill(CGRect(origin: .zero, size: size))
        return UIGraphicsGetImageFromCurrentImageContext()!
    }
}

public extension UIColor {
    public static func brightColor(hue: CGFloat) -> UIColor {
        return UIColor(hue: hue, saturation: 1, brightness: 1, alpha: 1)
    }
}
