import UIKit
import PlaygroundSupport

//: Universal loading from xib.

protocol LoadableFromXib: class {
    static var nibFileName: String { get }
}

extension LoadableFromXib where Self: UIView {
    static func load() -> Self {
        let bundle = Bundle(for: Self.self)
        let nib = UINib(nibName: nibFileName, bundle: bundle)
        let view = nib.instantiate(withOwner: nil)[0]
        return view as! Self
    }
}

//: ``CGRect`` category to add insets.

extension CGRect {
    func inset(by insets: UIEdgeInsets) -> CGRect {
        return CGRect(
            x: origin.x + insets.left,
            y: origin.y + insets.top,
            width: width - insets.left - insets.right,
            height: height - insets.top - insets.bottom
        )
    }
}

/*: 
 Universal collection cells.
 
 Collection cell that initialize view using ``init(frame:)`` method.
*/
class SimpleContentCollectionCell<View: UIView>: UICollectionViewCell {
    let view: View
    var contentInsets: UIEdgeInsets = .zero {
        didSet {
            view.frame = contentView.bounds.inset(by: contentInsets)
        }
    }
    
    override init(frame: CGRect) {
        view = View(frame: CGRect(origin: .zero, size: frame.size))
        
        super.init(frame: frame)
        
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.translatesAutoresizingMaskIntoConstraints = true
        view.frame = contentView.bounds
        contentView.addSubview(view)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        contentInsets = .zero
    }
}

//: Collection cell that initialize view by loading it from xib by ``LoadableFromXib`` protocol.
class LoadableFromXibContentCollectionCell<View: UIView>: UICollectionViewCell
                                                where View: LoadableFromXib {
    let view: View = .load()
    var contentInsets: UIEdgeInsets = .zero {
        didSet {
            view.frame = contentView.bounds.inset(by: contentInsets)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.translatesAutoresizingMaskIntoConstraints = true
        view.frame = contentView.bounds
        contentView.addSubview(view)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        contentInsets = .zero
    }
}

/*: 
 Universal table cells.

 Table cell that initialize view using ``init(frame:)`` method.
 */
class SimpleContentTableCell<View: UIView>: UITableViewCell {
    let view: View
    var contentInsets: UIEdgeInsets = .zero {
        didSet {
            view.frame = contentView.bounds.inset(by: contentInsets)
        }
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        view = View(frame: CGRect(origin: .zero, size: CGSize(width: 100, height: 100)))
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.translatesAutoresizingMaskIntoConstraints = true
        view.frame = contentView.bounds
        contentView.addSubview(view)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        contentInsets = .zero
    }
}

//: Table cell that initialize view by loading it from xib by ``LoadableFromXib`` protocol.
class LoadableFromXibContentTableCell<View: UIView>: UITableViewCell
            where View: LoadableFromXib {
    let view: View = .load()
    var contentInsets: UIEdgeInsets = .zero {
        didSet {
            view.frame = contentView.bounds.inset(by: contentInsets)
        }
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.translatesAutoresizingMaskIntoConstraints = true
        view.frame = contentView.bounds
        contentView.addSubview(view)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        contentInsets = .zero
    }
}

//: Example of universal collection cell usage. This example shows, how easy it is to create cell, contains ``UILabel``.

let cellReusableId = "cell"

typealias LabeledCell = SimpleContentCollectionCell<UILabel>

class CollectionData: NSObject, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 100
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellReusableId, for: indexPath) as! LabeledCell
        cell.view.text = "\(indexPath.row)"
        cell.backgroundColor = .white
        return cell
    }
}

let collectionView = UICollectionView(frame: CGRect(origin: .zero, size: CGSize(width: 320, height: 480)), collectionViewLayout: UICollectionViewFlowLayout())
collectionView.register(LabeledCell.self, forCellWithReuseIdentifier: cellReusableId)

let collectionData = CollectionData()
collectionView.dataSource = collectionData


//: Example of universal table cell usage. This example shows, how easy it is to create cell, contains ``UIImage``.

typealias ImageTableCell = SimpleContentTableCell<UIImageView>
let imageSize = CGSize(width: 50, height: 50)
let tableSize = 100

class TableData: NSObject, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableSize
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReusableId) as! ImageTableCell
        cell.view.contentMode = .scaleAspectFit
        let color = UIColor.brightColor(hue: CGFloat(indexPath.row) / CGFloat(tableSize))
        cell.view.image = UIImage.with(color: color, size:imageSize) //yes, delays because image creation takes time, but this is just an example
        cell.contentInsets = UIEdgeInsets(top: 5, left: 20, bottom: 5, right: 20)
        return cell
    }
}

let tableView = UITableView(frame: CGRect(origin: .zero, size: CGSize(width: 320, height: 480)), style: .plain)
tableView.register(ImageTableCell.self, forCellReuseIdentifier: cellReusableId)

let tableData = TableData()
tableView.dataSource = tableData


/*: 
 Change liveView property to tableView or collectionView to preview appropriate container on the right side of the playground.

 Those views are interactive, so don't forget to check how table view cells response on highlighting.
 */
PlaygroundPage.current.liveView = tableView
